module.exports = {
	options: {
		'empty-rules': false,
		important: false,
		ids: false
	},
	css: {
		src: ['<%=dirs.src%>/**/*.css']
	}
};
